package org.okayever.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val aiUrl = "https://okayever.org/"
    private val servicesUrl = "https://okayever.com/"
    private val mediaRequest = 4201
    private var webView: WebView? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var webPermission: PermissionRequest? = null
    private var pendingResources = emptyArray<String>()
    private var popupWebView: WebView? = null
    private var activeUrl = aiUrl
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 20, 47)
        window.navigationBarColor = Color.rgb(7, 20, 47)
        showHome()
    }

    private fun showHome() {
        webView?.apply { stopLoading(); loadUrl("about:blank"); removeAllViews(); destroy() }
        webView = null
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 20, 47))
            setPadding(dp(22), dp(20), dp(22), dp(26))
        }
        val brand = ImageView(this).apply {
            setImageResource(R.drawable.okayever_wordmark)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(112)))
        val caption = TextView(this).apply {
            text = "Choose where you want to go"
            textSize = 16f
            setTextColor(Color.rgb(202, 218, 244))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(28))
        }
        root.addView(caption)
        root.addView(choiceCard("OkayEver AI", "Chat, create, analyze files and use AI tools", aiUrl))
        root.addView(choiceCard("OkayEver Services", "IT services, orders and your client dashboard", servicesUrl))
        val note = TextView(this).apply {
            text = "Sign in through the website. Your account and activity remain connected to the live OkayEver sites."
            textSize = 13f
            setTextColor(Color.rgb(164, 184, 218))
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(24), dp(12), 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun choiceCard(title: String, subtitle: String, url: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(17), dp(20), dp(17))
            setBackgroundColor(Color.WHITE)
            elevation = dp(3).toFloat()
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 20f
            setTextColor(Color.rgb(8, 35, 91))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val detail = TextView(this).apply {
            text = subtitle
            textSize = 14f
            setTextColor(Color.rgb(69, 91, 129))
            setPadding(0, dp(6), 0, dp(13))
        }
        val enter = Button(this).apply {
            text = "Open  →"
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(44, 96, 239))
            setOnClickListener { openSite(url) }
        }
        card.addView(heading)
        card.addView(detail)
        card.addView(enter)
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) }
        card.background = rounded(Color.WHITE, dp(18))
        card.isClickable = true
        card.setOnClickListener { openSite(url) }
        return card.also { it.layoutParams = params }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openSite(url: String) {
        activeUrl = url
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(7, 20, 47))
            setPadding(dp(10), dp(4), dp(8), dp(4))
        }
        val home = Button(this).apply {
            text = "‹  Home"
            textSize = 13f
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(22, 43, 82))
            setOnClickListener { showHome() }
        }
        val title = TextView(this).apply {
            text = if (url.contains("okayever.org")) "OkayEver AI" else "OkayEver Services"
            textSize = 15f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val account = Button(this).apply {
            text = "Account"
            textSize = 12f
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(22, 43, 82))
            setOnClickListener {
                val accountUrl = if (activeUrl.contains("okayever.org")) "https://okayever.org/portal.php?page=chat" else "https://okayever.com/portal"
                webView?.loadUrl(accountUrl)
            }
        }
        val admin = Button(this).apply {
            text = "Admin"
            textSize = 12f
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(86, 45, 231))
            setOnClickListener { webView?.loadUrl(if (activeUrl.contains("okayever.org")) "https://okayever.org/admin.php" else "https://okayever.com/admin.php") }
        }
        bar.addView(home)
        bar.addView(title, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(account)
        bar.addView(admin)
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(54)))

        val page = WebView(this)
        webView = page
        val loading = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(loading, LinearLayout.LayoutParams(-1, dp(3)))
        page.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(page, true) }
        page.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme?.lowercase()
                if (scheme == "tel" || scheme == "mailto" || scheme == "sms") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                    return true
                }
                return scheme != "https" && scheme != "http"
            }
        }
        page.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                loading.progress = newProgress
                loading.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                popupWebView?.destroy()
                val popup = WebView(this@MainActivity).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(popupView: WebView, request: WebResourceRequest): Boolean {
                            val uri = request.url
                            if (uri.scheme.equals("https", ignoreCase = true)) page.loadUrl(uri.toString())
                            popupView.stopLoading()
                            popupView.destroy()
                            popupWebView = null
                            return true
                        }
                    }
                }
                popupWebView = popup
                val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                window.stopLoading()
                window.destroy()
                if (popupWebView === window) popupWebView = null
            }

            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = params.createIntent().apply { putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE) }
                return try { startActivityForResult(Intent.createChooser(intent, "Choose a file or image"), 4202); true }
                catch (_: Exception) { fileCallback = null; false }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val origin = request.origin.host?.lowercase() ?: ""
                if (!isOkayEverHost(origin)) { request.deny(); return }
                val needed = mutableListOf<String>()
                val allowed = mutableListOf<String>()
                request.resources.forEach { resource ->
                    when (resource) {
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> { allowed += resource; needed += Manifest.permission.CAMERA }
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> { allowed += resource; needed += Manifest.permission.RECORD_AUDIO }
                    }
                }
                if (allowed.isEmpty()) { request.deny(); return }
                val missing = needed.distinct().filter { ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) request.grant(allowed.toTypedArray())
                else { webPermission = request; pendingResources = allowed.toTypedArray(); ActivityCompat.requestPermissions(this@MainActivity, missing.toTypedArray(), mediaRequest) }
            }
        }
        page.setDownloadListener { downloadUrl, userAgent, contentDisposition, mimeType, _ ->
            runCatching {
                val request = DownloadManager.Request(Uri.parse(downloadUrl))
                    .setMimeType(mimeType)
                    .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(downloadUrl) ?: "")
                    .addRequestHeader("User-Agent", userAgent)
                    .setTitle(URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType))
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(this, "Could not start download", Toast.LENGTH_SHORT).show() }
        }
        root.addView(page, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        page.loadUrl(url)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4202) {
            val result = if (resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == mediaRequest) {
            val granted = permissions.isNotEmpty() && permissions.indices.all { grantResults.getOrNull(it) == PackageManager.PERMISSION_GRANTED }
            if (granted) webPermission?.grant(pendingResources) else webPermission?.deny()
            webPermission = null
            pendingResources = emptyArray()
        }
    }

    override fun onBackPressed() {
        val page = webView
        if (page?.canGoBack() == true) page.goBack() else if (page != null) showHome() else super.onBackPressed()
    }

    private fun isOkayEverHost(host: String): Boolean = host == "okayever.com" || host.endsWith(".okayever.com") || host == "okayever.org" || host.endsWith(".okayever.org")

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.Drawable = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(dp(1), Color.rgb(186, 205, 240))
    }
}
