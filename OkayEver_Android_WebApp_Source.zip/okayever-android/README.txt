OKAYEVER ANDROID WEB APP — SOURCE PROJECT

This Android Studio project opens the live OkayEver websites in one branded app:
  * OkayEver AI: https://okayever.org/
  * OkayEver Services: https://okayever.com/

The app does not contain a second copy of either website or database. Website
content, user accounts, orders, AI tools, admin access, subscriptions and data
remain on the existing web hosting. The attached SQL files are not used or
changed by this Android project.

APP FEATURES
  * OkayEver branded home screen with a choice of the two websites.
  * Website account and admin shortcuts in the in-app header.
  * WebView camera and microphone permission prompts, limited to OkayEver
    domains; file and image picker; download support; persistent website cookies.
  * HTTPS-only site connections. External payment and login pages can open
    inside the app and return through normal navigation.

BUILD AN INSTALLABLE APK (Android Studio)
1. Install Android Studio on a computer with internet access.
2. Open this extracted folder: okayever-android
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates app-debug.apk under app/build/outputs/apk/debug/.
   This APK can be installed manually on Android phones for initial use.
6. For a public website download and app updates, create a signed release APK
   in Build > Generate Signed Bundle / APK > APK. Keep the signing key and
   passwords secure and backed up. The same signing key is required for future
   updates to install over the existing app.

PUBLISHING THE APK FOR DOWNLOAD
After the signed release APK is produced, upload it to the public web root of
both okayever.com and okayever.org, for example as /downloads/OkayEver.apk.
Then add a Download OkayEver App link on each site. The websites are not
modified by this project; admins can add those links through the site's existing
content/admin controls where available.

IMPORTANT BUILD LIMITATION
The workspace used to prepare this source package does not include Android
Studio, Gradle, or the Android SDK. Therefore no APK binary was generated here.
The source project is ready to open and build in Android Studio. The Android
package name is org.okayever.app; keep it unchanged for future upgrades.
